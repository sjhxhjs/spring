This distribution of JDiff 1.1.1 is included in the Spring Framework build
because JDiff has a hard requirement on a JDIFF_HOME directory containing
jdiff.jar and xerces.jar as well as other presentation resources.

The actual generation of JDiff reports is driven by the `jdiff` task declared
in build.gradle in the project root.
